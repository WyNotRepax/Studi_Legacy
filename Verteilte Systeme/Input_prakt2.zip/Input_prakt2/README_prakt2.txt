In kap4_beispiele.zip gibt es kein Java-UDP-Server/Client-Beispiel.
Sie k�nnen sich an folgenden Vorlagen orientieren:
https://docs.oracle.com/javase/tutorial/networking/datagrams/clientServer.html
http://openbook.rheinwerk-verlag.de/java7/1507_11_011.html

Sample.txt: Bibel von 1912 (basiert auf Luther-Uebersetzung)
(Groesse: 3.824.872 Bytes)

Sample.bin: Bibel als PDF-Datei (Bin�rformat)
(Groesse: 4.370.012 Bytes)