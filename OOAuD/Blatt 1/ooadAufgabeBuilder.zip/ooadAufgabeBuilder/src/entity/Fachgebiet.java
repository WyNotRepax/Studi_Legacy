package entity;

import java.io.Serializable;

public enum Fachgebiet implements Serializable{
	ANALYSE, DESIGN, JAVA, C, TEST
}