package builder;

import entity.Fachgebiet;
import entity.Mitarbeiter;


public class MitarbeiterBuilder {
    //TODO
}
