Java Proxy Server
.................

Generierung der Software und weitere Informationen mit 'make'.
Ueber das makefile kann auch die Software aufgerufen 
('make run') werden. 

hje, Nov 2018

